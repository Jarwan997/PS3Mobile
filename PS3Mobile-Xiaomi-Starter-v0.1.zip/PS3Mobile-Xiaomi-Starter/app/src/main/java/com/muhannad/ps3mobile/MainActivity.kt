package com.muhannad.ps3mobile

import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    external fun nativeVulkanAvailable(): Boolean
    external fun nativeDeviceInfo(): String

    companion object {
        init { System.loadLibrary("ps3mobile") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(
                        device = Build.MODEL,
                        vulkan = runCatching { nativeVulkanAvailable() }.getOrDefault(false),
                        nativeInfo = runCatching { nativeDeviceInfo() }.getOrDefault("Native core not initialized")
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(device: String, vulkan: Boolean, nativeInfo: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("PS3 Mobile", style = MaterialTheme.typography.headlineLarge)
        Text("نسخة التطوير الأولى — مخصصة لأجهزة Android 64-bit")
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الجهاز: $device")
                Text("Vulkan: ${if (vulkan) "متاح" else "غير متاح"}")
                Text(nativeInfo)
            }
        }
        Button(onClick = { /* Game library picker will be added in phase 2 */ }) {
            Text("اختيار مجلد الألعاب")
        }
        Text(
            "المحرك الفعلي لمحاكاة PS3 لم يُضمّن بعد في هذه النسخة الأولية. " +
            "المرحلة التالية هي ربط نواة محاكاة PS3 مفتوحة المصدر مع طبقة Android/Vulkan."
        )
    }
}
