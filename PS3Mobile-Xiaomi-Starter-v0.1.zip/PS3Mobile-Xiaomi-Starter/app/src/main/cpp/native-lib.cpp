#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_muhannad_ps3mobile_MainActivity_nativeVulkanAvailable(
        JNIEnv* env, jobject thiz) {
    // Phase-1 probe placeholder. Real Vulkan device enumeration is added with the graphics backend.
    return JNI_TRUE;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_muhannad_ps3mobile_MainActivity_nativeDeviceInfo(
        JNIEnv* env, jobject thiz) {
    std::string s =
        "PS3 Mobile native layer ready | target: ARM64 | backend: Vulkan";
    return env->NewStringUTF(s.c_str());
}
