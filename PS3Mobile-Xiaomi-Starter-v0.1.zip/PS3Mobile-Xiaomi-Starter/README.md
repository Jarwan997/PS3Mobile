# PS3 Mobile — Xiaomi Starter

هذا مشروع Android أولي مخصص كنقطة انطلاق لبناء محاكي PS3 على هاتف Xiaomi/Redmi.

## الهدف
- ARM64 / Android
- Vulkan backend
- طبقة Native C++
- واجهة Android بسيطة
- تجهيز المشروع لربط نواة محاكاة PS3 مفتوحة المصدر

## مهم
هذه النسخة ليست محاكي PS3 كاملًا بعد، ولا تشغل ألعاب PS3. هي أول طبقة تشغيل/اختبار للمشروع.

المرحلة التقنية التالية:
1. إدخال/بناء نواة محاكاة PS3 متوافقة مع Android/ARM64.
2. ربط Vulkan renderer.
3. JIT/LLVM أو backend مناسب لـ ARM64.
4. إدارة shader cache والذاكرة.
5. game library + firmware/game-file selection.
6. game profiles وFPS/frame pacing.
7. اختبار الألعاب واحدة تلو الأخرى.

لا يتم تضمين ألعاب أو firmware مملوكين بحقوق نشر داخل المشروع.

## الجهاز المستهدف
Redmi Note 15 Pro+ 5G، مع Snapdragon 7s Gen 4 ونسخة 12GB/512GB وفق مواصفات Xiaomi الرسمية.
